module.exports = {
  index: (req, res, next) => {
    res.json({ message: 'Hello, world!' });
  },
};
